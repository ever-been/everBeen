package com.sun.xml.bind.v2.util;

/**
 * Created to record the caller stack trace in logging.
 *
 * @author Kohsuke Kawaguchi
 */
public class StackRecorder extends Throwable {
}
